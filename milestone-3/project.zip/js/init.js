(function($) {
  $(function() {
    // initialize the UI components
    $('.button-collapse').sideNav();
    $('.parallax').parallax();
    $('.modal-trigger').leanModal();
		 $('#score-form').hide();
		 $('#player-inputs').hide();
		 $('#time-holder').hide();

  }); // end of document ready
})(jQuery); // end of jQuery name space
